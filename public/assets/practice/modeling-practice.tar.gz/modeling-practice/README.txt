Учебные файлы курса «Базовый минимум Dimensional Modeling» с dataengineer.ru
https://dataengineer.ru/practice/modeling/

Выгрузка из OLTP-базы магазина спортивных товаров «Волна». Январь–июнь 2025.

data/categories.csv        категории товаров
data/products.csv          товары (текущая цена)
data/stores.csv            магазины
data/customers.csv         клиенты на 1 января 2025
data/customer_changes.csv  журнал изменений клиентов (переезды, VIP)
data/orders.csv            заказы (шапка)
data/order_items.csv       позиции заказов
data/inventory.csv         остатки на конец дня, июнь 2025
data/returns.csv           возвраты
