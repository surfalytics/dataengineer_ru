Учебные файлы курса «Базовый минимум статистики» с dataengineer.ru
https://dataengineer.ru/practice/stats/

data/orders.csv    1000 заказов: сумма, товары, время доставки
data/daily.csv     120 дней маркетинга: затраты, визиты, заказы, выручка
data/ab_test.csv   A/B-тест кнопки: 2000 пользователей в каждой группе
