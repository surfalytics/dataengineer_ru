#!/usr/bin/env bash
# Считает число заказов в каждом файле продаж.
for f in data/sales_*.csv; do
  echo "$f: $(tail -n +2 "$f" | wc -l | tr -d ' ') orders"
done
