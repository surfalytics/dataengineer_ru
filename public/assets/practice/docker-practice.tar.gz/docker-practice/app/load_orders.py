"""Загружает orders.csv в таблицу orders в Postgres."""

import csv
import os

import psycopg

path = os.environ.get("ORDERS_PATH", "/data/orders.csv")

conn = psycopg.connect(
    host=os.environ.get("DB_HOST", "localhost"),
    port=os.environ.get("DB_PORT", "5432"),
    dbname=os.environ.get("DB_NAME", "shop"),
    user=os.environ.get("DB_USER", "postgres"),
    password=os.environ["DB_PASSWORD"],
)

with conn, conn.cursor() as cur:
    cur.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id    integer PRIMARY KEY,
            order_date  date,
            customer_id integer,
            channel     text,
            amount      numeric(10, 2),
            status      text
        )
    """)
    cur.execute("TRUNCATE orders")
    with open(path, newline="") as f:
        rows = [
            (r["order_id"], r["order_date"], r["customer_id"],
             r["channel"], r["amount"], r["status"])
            for r in csv.DictReader(f)
        ]
    cur.executemany("INSERT INTO orders VALUES (%s, %s, %s, %s, %s, %s)", rows)
    print(f"Загружено строк: {len(rows)}")
