"""Читает orders.csv и печатает выручку по каналам. Только стандартная библиотека."""

import csv
import os
from collections import defaultdict

path = os.environ.get("ORDERS_PATH", "/data/orders.csv")

revenue = defaultdict(float)
count = 0
with open(path, newline="") as f:
    for row in csv.DictReader(f):
        count += 1
        if row["status"] == "completed":
            revenue[row["channel"]] += float(row["amount"])

print(f"Файл: {path}")
print(f"Заказов: {count}")
print("Выручка по каналам (только completed):")
for channel, total in sorted(revenue.items(), key=lambda x: -x[1]):
    print(f"  {channel:<8} {total:>10.2f}")
