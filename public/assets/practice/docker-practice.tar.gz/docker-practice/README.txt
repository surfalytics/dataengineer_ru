Учебные файлы курса «Базовый минимум Docker» с dataengineer.ru
https://dataengineer.ru/practice/docker/

data/orders.csv         500 заказов интернет-магазина
app/report.py           печатает выручку по каналам (только стандартная библиотека)
app/load_orders.py      грузит orders.csv в Postgres (нужен psycopg)
app/requirements.txt    зависимости для load_orders.py
